package com.girlkun.models.player;

/**
 *
 * @author 💖 Trần Lại 💖
 * @copyright 💖 GirlkuN 💖
 *
 */
public class Location {

    public int x;
    public int y;
}
