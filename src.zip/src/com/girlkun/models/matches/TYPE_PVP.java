package com.girlkun.models.matches;

/**
 *
 * @author ❤Girlkun75❤
 * @copyright ❤Trần Lại❤
 */
public enum TYPE_PVP {

    THACH_DAU,
    TRA_THU,
    DAI_HOI_VO_THUAT
    
}






















/**
 * Vui lòng không sao chép mã nguồn này dưới mọi hình thức.
 * Hãy tôn trọng tác giả của mã nguồn này.
 * Xin cảm ơn! - Girlkun75
 */