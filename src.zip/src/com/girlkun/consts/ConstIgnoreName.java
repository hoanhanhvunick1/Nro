package com.girlkun.consts;

/**
 *
 * @author 💖 Trần Lại 💖
 * @copyright 💖 GirlkuN 💖
 *
 */
public class ConstIgnoreName {

    public static final String[] IGNORE_NAME = {
    };

}
